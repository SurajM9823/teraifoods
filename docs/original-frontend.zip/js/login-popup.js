(function ($) {
  "use strict";

	$(document).on('groginShopPageInit', function () {
		groginThemeModule.popuplogin();
	});

	groginThemeModule.popuplogin = function() {
				
      const container = document.querySelector( '.authentication-modal' );
      const button = document.querySelectorAll( '.quick-button.login-form-button a, a[href="#account"], .user, .header-account' );

      if ( container !== null && button !== null ) {
        const close = container.querySelector( '.site-close' );
        const overlay = container.querySelector( '.site-drawer-overlay' );

        for( var i = 0; i < button.length; i++ ) {
          const self = button[i];

          self.addEventListener( 'click', (e) => {
            e.preventDefault();
            container.classList.add( 'is-active' );
          });
        }

        if ( close ) {
          close.addEventListener( 'click', (e) => {
            e.preventDefault();
            container.classList.remove( 'is-active' );
          });
        }

        if ( overlay ) {
          overlay.addEventListener( 'click', (e) => {
            e.preventDefault();
            container.classList.remove( 'is-active' );
          });
        }
      }
	  
	}
	
	$(document).ready(function() {
		groginThemeModule.popuplogin();
	});

})(jQuery);
